package tienda;

import javax.swing.*;
import java.awt.*;


/**
 * Ventana principal de la aplicación TechStore.
 *
 * Contiene:
 *   - Panel izquierdo: formulario de entrada de datos del producto.
 *   - Panel derecho:   área de log con el registro de operaciones.
 *
 * Componentes Swing utilizados:
 *   JFrame, JDialog, JLabel, JButton, JRadioButton, JTextField, JTextArea
 */
public class TiendaApp extends JFrame {

    // ── Componentes del formulario ───────────────────────────────────────────
    private JTextField txtNombre;
    private JTextField txtPrecio;

    private JRadioButton rbElectronica;
    private JRadioButton rbInformatica;
    private JRadioButton rbAudioVideo;
    private ButtonGroup  grupoCategorias;

    private JTextArea txtDescripcion;

    // ── Área de log ──────────────────────────────────────────────────────────
    private JTextArea txtLog;

    // ── Constructor ──────────────────────────────────────────────────────────

    public TiendaApp() {
        super("TechStore — Gestión de Productos");

        configurarVentana();
        construirUI();
    }

    // ── Configuración básica del JFrame ──────────────────────────────────────

    private void configurarVentana() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(750, 560));
    }

    //

    private void construirUI() {
        // Panel raíz: divide la ventana en izquierda (formulario) y derecha (log)
        JPanel panelRaiz = new JPanel(new GridLayout(1, 2, 10, 0));
        panelRaiz.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelRaiz.add(crearPanelFormulario());
        panelRaiz.add(crearPanelLog());

        setContentPane(panelRaiz);
        pack();
    }


    private JPanel crearPanelFormulario() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Datos del producto"));

        // ── Nombre ──────────────────────────────────────────────────────────
        panel.add(crearFila(new JLabel("Nombre del producto:"),
                            txtNombre = new JTextField(20)));

        panel.add(Box.createVerticalStrut(6));

        // ── Precio ──────────────────────────────────────────────────────────
        panel.add(crearFila(new JLabel("Precio (€):"),
                            txtPrecio = new JTextField(10)));

        panel.add(Box.createVerticalStrut(6));

        // ── Categoría (JRadioButton) ─────────────────────────────────────────
        panel.add(crearPanelCategorias());

        panel.add(Box.createVerticalStrut(6));

        // ── Descripción (JTextArea) ──────────────────────────────────────────
        panel.add(crearPanelDescripcion());

        panel.add(Box.createVerticalStrut(10));

        // ── Botones de acción ────────────────────────────────────────────────
        panel.add(crearPanelBotones());

        // Espacio flexible al final para no estirar los componentes
        panel.add(Box.createVerticalGlue());

        return panel;
    }


    private JPanel crearFila(JLabel etiqueta, JTextField campo) {
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        etiqueta.setPreferredSize(new Dimension(150, 25));
        fila.add(etiqueta);
        fila.add(campo);
        return fila;
    }


    private JPanel crearPanelCategorias() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panel.add(new JLabel("Categoría:"));

        rbElectronica  = new JRadioButton("Electrónica");
        rbInformatica  = new JRadioButton("Informática");
        rbAudioVideo   = new JRadioButton("Audio y Video");

        grupoCategorias = new ButtonGroup();
        grupoCategorias.add(rbElectronica);
        grupoCategorias.add(rbInformatica);

        panel.add(rbElectronica);
        panel.add(rbInformatica);
        panel.add(rbAudioVideo);

        return panel;
    }


    private JPanel crearPanelDescripcion() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

        JLabel lblDesc = new JLabel("Descripción:");
        panel.add(lblDesc, BorderLayout.SOUTH);

        txtDescripcion = new JTextArea(4, 20);
        txtDescripcion.setEditable(false);
        txtDescripcion.setLineWrap(true);       // ajuste de línea
        txtDescripcion.setWrapStyleWord(true);  // cortar por palabras
        panel.add(new JScrollPane(txtDescripcion), BorderLayout.CENTER);

        return panel;
    }


    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
       
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnSalir   = new JButton("Salir");

        btnLimpiar.addActionListener(e -> accionLimpiar());
        btnSalir.addActionListener(e   -> accionSalir());

        panel.add(btnLimpiar);
        panel.add(btnSalir);

        return panel;
    }

    private JPanel crearPanelLog() {
        JPanel panel = new JPanel(new BorderLayout(0, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Registro de operaciones"));

        txtLog = new JTextArea();
        txtLog.setEditable(false);
        txtLog.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtLog.setLineWrap(true);
        txtLog.setWrapStyleWord(true);

        panel.add(new JScrollPane(txtLog), BorderLayout.CENTER);

        return panel;
    }

    private void accionLimpiar() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtDescripcion.setText("");
        grupoCategorias.clearSelection();
        txtNombre.requestFocus();
    }

    private void accionSalir() {
        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Seguro que deseas salir de TechStore?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
}

