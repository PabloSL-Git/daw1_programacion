package tienda;

public class Main {

    public static void main(String[] args) {
        TiendaApp ventana = new TiendaApp();
        ventana.setVisible(true);
    }
}